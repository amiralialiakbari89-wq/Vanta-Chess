# Vanta Chess → APK

## ساخت APK بدون Android Studio (ساده‌ترین راه)
1. در github.com یک ریپوی جدید بسازید.
2. محتویات همین پوشه (از جمله پوشه‌ی مخفی `.github`) را در ریپو آپلود کنید.
3. تب **Actions** → «Build APK» → Run workflow.
4. بعد از ~5 دقیقه، از بخش Artifacts فایل `VantaChess-apk` را دانلود کنید (داخلش `app-debug.apk` است).

## ساخت روی کامپیوتر خودتان
نیاز: Node 18+، JDK 17، Android SDK
    npm install
    npx cap add android
    npx cap sync android
    cd android && ./gradlew assembleDebug
خروجی: android/app/build/outputs/apk/debug/app-debug.apk
